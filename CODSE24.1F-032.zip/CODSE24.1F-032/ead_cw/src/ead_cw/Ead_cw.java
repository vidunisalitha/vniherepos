/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ead_cw;

import ead_cw.View.DashboardView;
import ead_cw.View.PaymentView;
import ead_cw.View.StudentView;
import ead_cw.View.TeacherView;

/**
 *
 * @author Vnihe
 */
public class Ead_cw {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //StudentView stdgui = new StudentView();
        //stdgui.setVisible(true);
            
        //TeacherView tchgui = new TeacherView();
        //tchgui.setVisible(true);
        
        //PaymentView paygui = new PaymentView();
        //paygui.setVisible(true);
        
        DashboardView dashgui = new DashboardView();
        dashgui.setVisible(true);
    }
    
}
