/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ead_cw.Controller;

import ead_cw.Model.DBConnection;
import ead_cw.Model.StudentModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Vnihe
 */
public class StudentController {
    public List<String[]> readStudents() {
        List<String[]> students = new ArrayList<>();
        String sql = "SELECT std_id, fname, lname, dob, address, grade, fee FROM Student";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                students.add(new String[]{rs.getString("std_id"), rs.getString("fname"), rs.getString("lname"), rs.getString("dob"), rs.getString("address"), String.valueOf(rs.getInt("grade")), String.valueOf(rs.getDouble("fee"))});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return students;
    }
    
    public List<String[]> readStudentTele() {
        List<String[]> studenttele = new ArrayList<>();
        String sql = "SELECT std_id, tele_no FROM Student_tele";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                studenttele.add(new String[]{rs.getString("std_id"), rs.getString("tele_no")});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return studenttele;
    }
    
    public void addStudent(String std_id, String fname, String lname, String dob, String address, int grade, double fee) {
        String sql = "INSERT INTO Student (std_id, fname, lname, dob, address, grade, fee) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, std_id);
            pstmt.setString(2, fname);
            pstmt.setString(3, lname);
            pstmt.setString(4, dob);
            pstmt.setString(5, address);
            pstmt.setInt(6, grade);
            pstmt.setDouble(7, fee);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void addStudentTele(String std_id, String tele) {
        String sql = "INSERT INTO Student_tele (std_id, tele_no) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, std_id);
            pstmt.setString(2, tele);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void updateStudent(String std_id, String fname, String lname, String dob, String address, int grade, double fee) {
        String sql = "UPDATE Student SET fname = ?, lname = ?, dob = ?, address = ?, grade = ?, fee = ? WHERE std_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, fname);
            pstmt.setString(2, lname);
            pstmt.setString(3, dob);
            pstmt.setString(4, address);
            pstmt.setInt(5, grade);
            pstmt.setDouble(6, fee);
            pstmt.setString(7, std_id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void updateStudentTele(String std_id, String tele) {
        String sql = "UPDATE Student_tele SET tele_no = ? WHERE std_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, tele);
            pstmt.setString(2, std_id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void deleteStudent(String id) {
        String sql = "DELETE FROM Student WHERE std_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public StudentModel searchUser(String id) {
        String sql = "SELECT * FROM Student WHERE std_id = ?";
        try (Connection conn = DBConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new StudentModel(rs.getString("std_id"), rs.getString("fname"), rs.getString("lname"), rs.getString("dob"), rs.getString("address"), rs.getInt("grade"), rs.getDouble("fee"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }
}
