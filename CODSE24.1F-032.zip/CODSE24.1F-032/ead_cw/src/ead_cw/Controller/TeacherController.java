/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ead_cw.Controller;

import ead_cw.Model.DBConnection;
import ead_cw.Model.StudentModel;
import ead_cw.Model.TeacherModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Vnihe
 */
public class TeacherController {
    public List<String[]> readTeachers() {
        List<String[]> teachers = new ArrayList<>();
        String sql = "SELECT tchr_id, fname, lname, nic, address, subject, salary FROM Teacher";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                teachers.add(new String[]{rs.getString("tchr_id"), rs.getString("fname"), rs.getString("lname"), rs.getString("nic"), rs.getString("address"), rs.getString("subject"), String.valueOf(rs.getDouble("salary"))});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return teachers;
    }
    
    public List<String[]> readTeacherTele() {
        List<String[]> teachertele = new ArrayList<>();
        String sql = "SELECT tchr_id, tele_no FROM Teacher_tele";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                teachertele.add(new String[]{rs.getString("tchr_id"), rs.getString("tele_no")});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return teachertele;
    }
    
    public void addTeacher(String tchr_id, String fname, String lname, String nic, String address, String subject, double salary) {
        String sql = "INSERT INTO Teacher (tchr_id, fname, lname, nic, address, subject, salary) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, tchr_id);
            pstmt.setString(2, fname);
            pstmt.setString(3, lname);
            pstmt.setString(4, nic);
            pstmt.setString(5, address);
            pstmt.setString(6, subject);
            pstmt.setDouble(7, salary);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void addTeacherTele(String tchr_id, String tele) {
        String sql = "INSERT INTO Teacher_tele (tchr_id, tele_no) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, tchr_id);
            pstmt.setString(2, tele);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void updateTeacher(String tchr_id, String fname, String lname, String nic, String address, String subject, double salary) {
        String sql = "UPDATE Teacher SET fname = ?, lname = ?, nic = ?, address = ?, subject = ?, salary = ? WHERE tchr_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, fname);
            pstmt.setString(2, lname);
            pstmt.setString(3, nic);
            pstmt.setString(4, address);
            pstmt.setString(5, subject);
            pstmt.setDouble(6, salary);
            pstmt.setString(7, tchr_id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void updateTeacherTele(String tchr_id, String tele) {
        String sql = "UPDATE Teacher_tele SET tele_no = ? WHERE tchr_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, tele);
            pstmt.setString(2, tchr_id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void deleteTeacher(String id) {
        String sql = "DELETE FROM Teacher WHERE tchr_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public TeacherModel searchUser(String id) {
        String sql = "SELECT * FROM Teacher WHERE tchr_id = ?";
        try (Connection conn = DBConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new TeacherModel(rs.getString("tchr_id"), rs.getString("fname"), rs.getString("lname"), rs.getString("nic"), rs.getString("address"), rs.getString("subject"), rs.getDouble("salary"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }
}
