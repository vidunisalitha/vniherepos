/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ead_cw.Controller;

import ead_cw.Model.DBConnection;
import ead_cw.Model.StudentModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

/**
 *
 * @author Vnihe
 */
public class PaymentController {
    public List<String[]> readPayments() {
        List<String[]> payments = new ArrayList<>();
        String sql = "SELECT pay_id, amount, date, std_id, tchr_id FROM Payment";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                payments.add(new String[]{rs.getString("pay_id"), String.valueOf(rs.getDouble("amount")), rs.getString("date"), rs.getString("std_id"), rs.getString("tchr_id")});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return payments;
        
        
    }
    
    public static void StdComboBox(JComboBox<String> comboBox) {
        String sql = "SELECT std_id FROM Student";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            // Clear existing items in the combo box
            comboBox.removeAllItems();

            // Add each ID to the combo box
            while (rs.next()) {
                String id = rs.getString("std_id"); // Assuming 'id' is the column name
                comboBox.addItem(id);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public static void TchComboBox(JComboBox<String> comboBox) {
        String sql = "SELECT tchr_id FROM Teacher";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            // Clear existing items in the combo box
            comboBox.removeAllItems();

            // Add each ID to the combo box
            while (rs.next()) {
                String id = rs.getString("tchr_id"); // Assuming 'id' is the column name
                comboBox.addItem(id);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public static String StdFee(String id) {
        String sql = "SELECT fee FROM Student WHERE std_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, id); // Set the parameter for the query
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return String.valueOf(rs.getDouble("fee")); // Return the fee
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred while fetching the name: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return null; // Return null if no name is found
    }
    
    public static String TchFee(String id) {
        String sql = "SELECT salary FROM Teacher WHERE tchr_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, id); // Set the parameter for the query
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return String.valueOf(rs.getDouble("salary")); // Return the fee
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred while fetching the name: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return null; // Return null if no name is found
    }
    
    public void addPayment(String pay_id, double amount, String date, String std_id, String tchr_id) {
        String sql = "INSERT INTO Teacher (pay_id, amount, date, std_id, tchr_id) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, pay_id);
            pstmt.setDouble(2, amount);
            pstmt.setString(3, date);
            pstmt.setString(4, std_id);
            pstmt.setString(5, tchr_id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
