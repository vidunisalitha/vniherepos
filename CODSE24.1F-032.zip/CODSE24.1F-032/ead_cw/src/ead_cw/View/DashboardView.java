/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ead_cw.View;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author Vnihe
 */
public class DashboardView extends JFrame{
    public DashboardView(){
        //GUI Components
        setTitle("Tution Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 600);
        setLayout(null);
        
        JLabel lblid = new JLabel("TUTION MANAGEMENT SYSTEM");
        lblid.setBounds(500, 150, 500, 30);
        add(lblid);
        
        JButton btnstd = new JButton("MANAGE STUDENTS");
        btnstd.setBounds(300, 200, 200, 30);
        add(btnstd);
        
        JButton btntch = new JButton("MANAGE TEACHERS");
        btntch.setBounds(500, 200, 200, 30);
        add(btntch);
        
        JButton btnpay = new JButton("MANAGE PAYMENTS");
        btnpay.setBounds(700, 200, 200, 30);
        add(btnpay);
        
        btnstd.addActionListener(e -> {
            StudentView stdgui = new StudentView();
            stdgui.setVisible(true);
            //this.dispose();
        });
        
        btntch.addActionListener(e -> {
            TeacherView tchgui = new TeacherView();
            tchgui.setVisible(true);
            //this.dispose();
        });
        
        btnpay.addActionListener(e -> {
            PaymentView paygui = new PaymentView();
            paygui.setVisible(true);
            //this.dispose();
        });
    }
}
