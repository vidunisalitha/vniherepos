/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ead_cw.View;

import ead_cw.Controller.StudentController;
import ead_cw.Controller.TeacherController;
import ead_cw.Model.StudentModel;
import ead_cw.Model.TeacherModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Vnihe
 */
public class TeacherView extends JFrame{
    private JTextField txtid, txtfname, txtlname, txtnic, txtaddress, txttele1, txttele2, txtfee;
    private JTable tblteacher;
    private JTable tblteachertele;
    private DefaultTableModel tblmodel;
    private DefaultTableModel tblmodel2;
    private TeacherController tchcon;
    
    private double fps=0;
    
    public TeacherView(){
        tchcon = new TeacherController();
        
        //GUI Components
        setTitle("Manage Teachers");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 600);
        setLayout(null);
        
        JLabel lblid = new JLabel("Teacher ID: ");
        lblid.setBounds(20, 20, 150, 30);
        add(lblid);
        
        JLabel lblfname = new JLabel("First Name: ");
        lblfname.setBounds(20, 50, 150, 30);
        add(lblfname);
        
        JLabel lbllname = new JLabel("Last Name: ");
        lbllname.setBounds(20, 80, 150, 30);
        add(lbllname);
        
        JLabel lbldob = new JLabel("NIC Number ");
        lbldob.setBounds(20, 110, 150, 30);
        add(lbldob);
        
        JLabel lbladdress = new JLabel("Address: ");
        lbladdress.setBounds(20, 140, 150, 30);
        add(lbladdress);
        
        JLabel lbltele1 = new JLabel("Tel 01: ");
        lbltele1.setBounds(20, 170, 150, 30);
        add(lbltele1);
        
        JLabel lbltele2 = new JLabel("Tel 02: ");
        lbltele2.setBounds(20, 200, 150, 30);
        add(lbltele2);
        
        JLabel lblgrade = new JLabel("Subject: ");
        lblgrade.setBounds(20, 230, 150, 30);
        add(lblgrade);
        
        JLabel lblfee = new JLabel("Payment: ");
        lblfee.setBounds(20, 400, 150, 30);
        add(lblfee);
        
        txtid = new JTextField();
        txtid.setBounds(120, 20, 330, 30);
        add(txtid);
        
        txtfname = new JTextField();
        txtfname.setBounds(120, 50, 330, 30);
        add(txtfname);
        
        txtlname = new JTextField();
        txtlname.setBounds(120, 80, 330, 30);
        add(txtlname);
        
        txtnic = new JTextField();
        txtnic.setBounds(120, 110, 330, 30);
        add(txtnic);
        
        txtaddress = new JTextField();
        txtaddress.setBounds(120, 140, 330, 30);
        add(txtaddress);
        
        txttele1 = new JTextField();
        txttele1.setBounds(120, 170, 330, 30);
        add(txttele1);
        
        txttele2 = new JTextField();
        txttele2.setBounds(120, 200, 330, 30);
        add(txttele2);
        
        txtfee = new JTextField();
        txtfee.setBounds(120, 400, 330, 30);
        //txtfee.setEditable(false);
        add(txtfee);
        
        String[] subject = {"Mathematics", "Science", "Sinhala", "English", "History", "Tamil", "ICT"};
        JComboBox<String> cboxsubject = new JComboBox<>(subject);
        cboxsubject.setBounds(120, 230, 330, 30);
        add(cboxsubject);
        
        JButton btnsearch = new JButton("SEARCH");
        btnsearch.setBounds(460, 20, 100, 30);
        add(btnsearch);
        
        JButton btnadd = new JButton("ADD");
        btnadd.setBounds(20, 450, 100, 30);
        add(btnadd);
        
        JButton btnupdate = new JButton("UPDATE");
        btnupdate.setBounds(130, 450, 100, 30);
        add(btnupdate);
        
        JButton btndelete = new JButton("DELETE");
        btndelete.setBounds(240, 450, 100, 30);
        add(btndelete);
        
        JButton btnclear = new JButton("CLEAR");
        btnclear.setBounds(350, 450, 100, 30);
        add(btnclear);
        
        JButton btnback = new JButton("BACK");
        btnback.setBounds(20, 490, 100, 30);
        add(btnback);
        
        tblteacher = new JTable();
        tblmodel = new DefaultTableModel(new String[]{"ID", "First Name", "Last Name", "Date of Birth", "Address", "Grade", "Fee"}, 0);
        tblteacher.setModel(tblmodel);
        JScrollPane tblscroll = new JScrollPane(tblteacher);
        tblscroll.setBounds(580, 20, 600, 150);
        add(tblscroll);
        
        tblteachertele = new JTable();
        tblmodel2 = new DefaultTableModel(new String[]{"ID", "Telephone Number"}, 0);
        tblteachertele.setModel(tblmodel2);
        JScrollPane tblscroll2 = new JScrollPane(tblteachertele);
        tblscroll2.setBounds(580, 180, 600, 150);
        add(tblscroll2);
        
        //Event handling
        btnadd.addActionListener(e -> {
            String id = txtid.getText().trim();
            String fname = txtfname.getText().trim();
            String lname = txtlname.getText().trim();
            String nic = txtnic.getText().trim();
            String address = txtaddress.getText().trim();
            String subject1 = (String) cboxsubject.getSelectedItem();
            String fee = txtfee.getText().trim();
            String tele1 = txttele1.getText().trim();
            String tele2 = txttele2.getText().trim();

            try {
                // Validate ID
                if (id.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please add an ID number!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
                }
                if (!id.matches("tch\\d+")) { // Example: ID must start with "std" followed by digits
                    JOptionPane.showMessageDialog(null, "ID must be in the format 'tch001'!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
                }
                
                // Validate other fields
                if (fname.isEmpty() || lname.isEmpty() || address.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
                }

                // Add user to the database
                tchcon.addTeacher(id, fname, lname, nic, address, subject1, Double.parseDouble(fee));
                tchcon.addTeacherTele(id, tele1);
                tchcon.addTeacherTele(id, tele2);

                // Refresh table
                refreshTable();

                JOptionPane.showMessageDialog(null, "User added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                // Clear fields
                txtid.setText(null);
                txtfname.setText(null);
                txtlname.setText(null);
                txtaddress.setText(null);
                txtfee.setText(null);
                txtnic.setText(null);
                cboxsubject.setSelectedIndex(-1);
                txttele1.setText(null);
                txttele2.setText(null);

            } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Payment must be valid numbers!", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "An error occurred: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }       
        });
        
        btnupdate.addActionListener(e -> {
            String id = txtid.getText().trim();
            String fname = txtfname.getText().trim();
            String lname = txtlname.getText().trim();
            String nic = txtnic.getText().trim();
            String address = txtaddress.getText().trim();
            String subject1 = (String) cboxsubject.getSelectedItem();
            String fee = txtfee.getText().trim();
            String tele1 = txttele1.getText().trim();
            String tele2 = txttele2.getText().trim();
            try {
                if (id.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please add an ID number!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
                }

                // Add user to the database
                tchcon.updateTeacher(id, fname, lname, nic, address, subject1, Double.parseDouble(fee));
                tchcon.updateTeacherTele(id, tele1);
                tchcon.updateTeacherTele(id, tele2);

                // Refresh table
                refreshTable();
                
                JOptionPane.showMessageDialog(this, "User updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                // Clear fields
                txtid.setText(null);
                txtfname.setText(null);
                txtlname.setText(null);
                txtaddress.setText(null);
                txtfee.setText(null);
                cboxsubject.setSelectedIndex(-1);
                txttele1.setText(null);
                txttele2.setText(null);
                txtnic.setText(null);

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID must be a valid number!", "Error", JOptionPane.ERROR_MESSAGE);
            }

        });
        
        btndelete.addActionListener(e -> {
            String id = txtid.getText();
            try {
                if (id.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please add an ID number!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
                }

                // Add user to the database
                tchcon.deleteTeacher(id);

                // Refresh table
                refreshTable();
                
                JOptionPane.showMessageDialog(this, "User deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                // Clear fields
                txtid.setText(null);
                txtfname.setText(null);
                txtlname.setText(null);
                txtaddress.setText(null);
                txtfee.setText(null);
                cboxsubject.setSelectedIndex(-1);
                txttele1.setText(null);
                txttele2.setText(null);
                txtnic.setText(null);

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID must be a valid number!", "Error", JOptionPane.ERROR_MESSAGE);
            }
            refreshTable();
        });
        
        btnclear.addActionListener(e -> {
            // Clear fields
                txtid.setText(null);
                txtfname.setText(null);
                txtlname.setText(null);
                txtaddress.setText(null);
                txtfee.setText(null);
                cboxsubject.setSelectedIndex(-1);
                txttele1.setText(null);
                txttele2.setText(null);
                txtnic.setText(null);
            refreshTable();
        });
        
        btnsearch.addActionListener(e -> {
            try {
                    String id = txtid.getText();
                    TeacherModel tchmodel = tchcon.searchUser(id);
                    if (tchmodel != null) {
                        txtfname.setText(tchmodel.getFname());
                        txtlname.setText(tchmodel.getLname());
                        txtaddress.setText(tchmodel.getAddress());
                        txtnic.setText(tchmodel.getNic());
                        txtfee.setText(String.valueOf(tchmodel.getSalary()));
                        cboxsubject.setSelectedItem(String.valueOf(tchmodel.getSubject()));
                    }
                    else {
                        JOptionPane.showMessageDialog(this, "User not found!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
            } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Please enter a valid ID!", "Error", JOptionPane.ERROR_MESSAGE);
            }
            refreshTable();
        });
        
        tblteacher.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int selectedRow = tblteacher.getSelectedRow(); // Get the selected row index
                if (selectedRow != -1) {
                    // Load data from the selected row into the text fields
                    txtid.setText(tblmodel.getValueAt(selectedRow, 0).toString());
                    //txtname.setText(tblmodel.getValueAt(selectedRow, 1).toString());
                    //txtaddress.setText(tblmodel.getValueAt(selectedRow, 2).toString());
                }
            }
        });
        
        btnback.addActionListener(e -> {
            this.dispose();
        });

        
        refreshTable();
        cboxsubject.setSelectedIndex(-1);
        
        
        
    }
    
    private void refreshTable() {
        tblmodel.setRowCount(0);
        List<String[]> users = tchcon.readTeachers();
        for (String[] user : users) {
            tblmodel.addRow(user);
        }
        
        tblmodel2.setRowCount(0);
        List<String[]> users2 = tchcon.readTeacherTele();
        for (String[] user : users2) {
            tblmodel2.addRow(user);
        }
    }
    
    
    
}
