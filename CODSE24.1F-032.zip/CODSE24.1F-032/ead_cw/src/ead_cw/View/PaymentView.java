/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ead_cw.View;

import ead_cw.Controller.PaymentController;
import static ead_cw.Controller.PaymentController.StdComboBox;
import static ead_cw.Controller.PaymentController.TchComboBox;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Vnihe
 */
public class PaymentView extends JFrame{
    private JTextField txtid, txtamount;
    private JTable tblpayment;
    private DefaultTableModel tblmodel;
    private PaymentController paycon;
    
    public PaymentView(){
        paycon = new PaymentController();
        
        //GUI Components
        setTitle("Manage Payments");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 600);
        setLayout(null);
        
        JLabel lblid = new JLabel("Payment ID: ");
        lblid.setBounds(20, 20, 150, 30);
        add(lblid);
        
        JLabel lblpaydate = new JLabel("Pay Date: ");
        lblpaydate.setBounds(20, 50, 150, 30);
        add(lblpaydate);
        
        JLabel lblstdid = new JLabel("Student ID: ");
        lblstdid.setBounds(20, 80, 150, 30);
        add(lblstdid);
        
        JLabel lbltchid = new JLabel("Teacher ID: ");
        lbltchid.setBounds(20, 110, 150, 30);
        add(lbltchid);
        
        JLabel lblamount = new JLabel("Amount: ");
        lblamount.setBounds(20, 400, 150, 30);
        add(lblamount);
        
        txtid = new JTextField();
        txtid.setBounds(120, 20, 330, 30);
        add(txtid);
        
        txtamount = new JTextField();
        txtamount.setBounds(120, 400, 330, 30);
        txtamount.setEditable(false);
        add(txtamount);
        
        String[] days = new String[31];
        for (int i = 0; i < 31; i++) {
            days[i] = String.format("%02d", i + 1);  // 01, 02, ..., 31
        }
        JComboBox<String> cboxday = new JComboBox<>(days);
        cboxday.setBounds(120, 50, 100, 30);
        add(cboxday);
        
        String[] months = {
            "January", "February", "March", "April", "May", "June", 
            "July", "August", "September", "October", "November", "December"
        };
        JComboBox<String> cboxmonth = new JComboBox<>(months);
        cboxmonth.setBounds(230, 50, 100, 30);
        add(cboxmonth);
        
        String[] years = new String[51];
        for (int i = 0; i < 51; i++) {
            years[i] = String.valueOf(2000 + i);  // 2020, 2021, ..., 2030
        }
        JComboBox<String> cboxyear = new JComboBox<>(years);
        cboxyear.setBounds(340, 50, 110, 30);
        add(cboxyear);
        
        JComboBox<String> cboxstdid = new JComboBox<>();
        cboxstdid.setBounds(120, 80, 330, 30);
        StdComboBox(cboxstdid);
        add(cboxstdid);
        
        JComboBox<String> cboxtchid = new JComboBox<>();
        cboxtchid.setBounds(120, 110, 330, 30);
        TchComboBox(cboxtchid);
        add(cboxtchid);
        
        JButton btnsearch = new JButton("SEARCH");
        btnsearch.setBounds(460, 20, 100, 30);
        add(btnsearch);
        
        JButton btnadd = new JButton("ADD");
        btnadd.setBounds(20, 450, 100, 30);
        add(btnadd);
        
        JButton btnupdate = new JButton("UPDATE");
        btnupdate.setBounds(130, 450, 100, 30);
        add(btnupdate);
        
        JButton btndelete = new JButton("DELETE");
        btndelete.setBounds(240, 450, 100, 30);
        add(btndelete);
        
        JButton btnclear = new JButton("CLEAR");
        btnclear.setBounds(350, 450, 100, 30);
        add(btnclear);
        
        JButton btnback = new JButton("BACK");
        btnback.setBounds(20, 490, 100, 30);
        add(btnback);
        
        tblpayment = new JTable();
        tblmodel = new DefaultTableModel(new String[]{"ID", "Amount", "Pay Date", "Student ID", "Teacher ID"}, 0);
        tblpayment.setModel(tblmodel);
        JScrollPane tblscroll = new JScrollPane(tblpayment);
        tblscroll.setBounds(580, 20, 600, 150);
        add(tblscroll);
        
        //Event Handling
        
        cboxstdid.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (cboxstdid.getSelectedIndex() > -1) { // Ignore the "Select" option
                    cboxtchid.setEnabled(false); // Disable the second combo box
                   
                }
                String fee = paycon.StdFee(String.valueOf(cboxstdid.getSelectedItem()));
                txtamount.setText(fee);
            }
        });

        
        cboxtchid.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (cboxtchid.getSelectedIndex() > -1) { // Ignore the "Select" option
                    cboxstdid.setEnabled(false); // Disable the second combo box
                }
                String salary = paycon.TchFee(String.valueOf(cboxstdid.getSelectedItem()));
                txtamount.setText(salary);
            }
        });
        
        btnadd.addActionListener(e -> {
            String id = txtid.getText().trim();
            String payday = ((String) cboxday.getSelectedItem()) + "/" +
                 ((String) cboxmonth.getSelectedItem()) + "/" +
                 ((String) cboxyear.getSelectedItem());
            String stdid = (String) cboxstdid.getSelectedItem();
            String tchid = (String) cboxtchid.getSelectedItem();
            String amount = txtamount.getText().trim();

            try {
                // Validate ID
                if (id.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please add an ID number!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
                }
                if (!id.matches("pay\\d+")) { // Example: ID must start with "pay" followed by digits
                    JOptionPane.showMessageDialog(null, "ID must be in the format 'pay001'!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
                }
                
                // Validate other fields
                if (amount.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
                }

                // Add user to the database
                paycon.addPayment(id, Double.parseDouble(amount), payday, stdid, tchid);

                // Refresh table
                refreshTable();

                JOptionPane.showMessageDialog(null, "User added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                // Clear fields
                txtid.setText(null);
                cboxstdid.setSelectedIndex(-1);
                cboxtchid.setSelectedIndex(-1);
                cboxday.setSelectedIndex(-1);
                cboxmonth.setSelectedIndex(-1);
                cboxyear.setSelectedIndex(-1);
                txtamount.setText(null);

            } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Payment must be valid numbers!", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "An error occurred: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }       
        });
        
        btnback.addActionListener(e -> {
            this.dispose();
        });
        
        refreshTable();
    }
    
    private void refreshTable() {
        tblmodel.setRowCount(0);
        List<String[]> users = paycon.readPayments();
        for (String[] user : users) {
            tblmodel.addRow(user);
        }
    }
    
}