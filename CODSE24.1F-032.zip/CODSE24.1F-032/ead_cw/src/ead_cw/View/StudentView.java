/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ead_cw.View;

import ead_cw.Controller.StudentController;
import ead_cw.Model.StudentModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Vnihe
 */
public class StudentView extends JFrame{
    private JTextField txtid, txtfname, txtlname, txtaddress, txttele1, txttele2, txtfee;
    private JTable tblstudent;
    private JTable tblstudenttele;
    private DefaultTableModel tblmodel;
    private DefaultTableModel tblmodel2;
    private StudentController stdcon;
    
    private double fps=0;
    
    public StudentView(){
        stdcon = new StudentController();
        
        //GUI Components
        setTitle("Manage Students");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 600);
        setLayout(null);
        
        JLabel lblid = new JLabel("Student ID: ");
        lblid.setBounds(20, 20, 150, 30);
        add(lblid);
        
        JLabel lblfname = new JLabel("First Name: ");
        lblfname.setBounds(20, 50, 150, 30);
        add(lblfname);
        
        JLabel lbllname = new JLabel("Last Name: ");
        lbllname.setBounds(20, 80, 150, 30);
        add(lbllname);
        
        JLabel lbldob = new JLabel("Date of Birth: ");
        lbldob.setBounds(20, 110, 150, 30);
        add(lbldob);
        
        JLabel lbladdress = new JLabel("Address: ");
        lbladdress.setBounds(20, 140, 150, 30);
        add(lbladdress);
        
        JLabel lbltele1 = new JLabel("Tel 01: ");
        lbltele1.setBounds(20, 170, 150, 30);
        add(lbltele1);
        
        JLabel lbltele2 = new JLabel("Tel 02: ");
        lbltele2.setBounds(20, 200, 150, 30);
        add(lbltele2);
        
        JLabel lblgrade = new JLabel("Grade: ");
        lblgrade.setBounds(20, 230, 150, 30);
        add(lblgrade);
        
        JLabel lblsubject = new JLabel("Select Subjects: ");
        lblsubject.setBounds(20, 260, 150, 30);
        add(lblsubject);
        
        JLabel lblfee = new JLabel("Fee: ");
        lblfee.setBounds(20, 400, 150, 30);
        add(lblfee);
        
        txtid = new JTextField();
        txtid.setBounds(120, 20, 330, 30);
        add(txtid);
        
        txtfname = new JTextField();
        txtfname.setBounds(120, 50, 330, 30);
        add(txtfname);
        
        txtlname = new JTextField();
        txtlname.setBounds(120, 80, 330, 30);
        add(txtlname);
        
        txtaddress = new JTextField();
        txtaddress.setBounds(120, 140, 330, 30);
        add(txtaddress);
        
        txttele1 = new JTextField();
        txttele1.setBounds(120, 170, 330, 30);
        add(txttele1);
        
        txttele2 = new JTextField();
        txttele2.setBounds(120, 200, 330, 30);
        add(txttele2);
        
        txtfee = new JTextField();
        txtfee.setBounds(120, 400, 330, 30);
        txtfee.setEditable(false);
        add(txtfee);
        
        String[] grade = {"6", "7", "8", "9", "10", "11"};
        JComboBox<String> cboxgrade = new JComboBox<>(grade);
        cboxgrade.setBounds(120, 230, 330, 30);
        add(cboxgrade);
        
        String[] days = new String[31];
        for (int i = 0; i < 31; i++) {
            days[i] = String.format("%02d", i + 1);  // 01, 02, ..., 31
        }
        JComboBox<String> cboxday = new JComboBox<>(days);
        cboxday.setBounds(120, 110, 100, 30);
        add(cboxday);
        
        String[] months = {
            "January", "February", "March", "April", "May", "June", 
            "July", "August", "September", "October", "November", "December"
        };
        JComboBox<String> cboxmonth = new JComboBox<>(months);
        cboxmonth.setBounds(230, 110, 100, 30);
        add(cboxmonth);
        
        String[] years = new String[51];
        for (int i = 0; i < 51; i++) {
            years[i] = String.valueOf(2000 + i);  // 2020, 2021, ..., 2030
        }
        JComboBox<String> cboxyear = new JComboBox<>(years);
        cboxyear.setBounds(340, 110, 110, 30);
        add(cboxyear);
        
        JCheckBox chkmaths = new JCheckBox("Mathematics");
        chkmaths.setBounds(20, 290, 100, 30);
        add(chkmaths);
        
        JCheckBox chkscs = new JCheckBox("Science");
        chkscs.setBounds(140, 290, 100, 30);
        add(chkscs);
        
        JCheckBox chksin = new JCheckBox("Sinhala");
        chksin.setBounds(260, 290, 100, 30);
        add(chksin);
        
        JCheckBox chkeng = new JCheckBox("English");
        chkeng.setBounds(380, 290, 100, 30);
        add(chkeng);
        
        JCheckBox chkhis = new JCheckBox("History");
        chkhis.setBounds(20, 320, 100, 30);
        add(chkhis);
        
        JCheckBox chktml = new JCheckBox("Tamil");
        chktml.setBounds(140, 320, 100, 30);
        add(chktml);
        
        JCheckBox chkict = new JCheckBox("ICT");
        chkict.setBounds(260, 320, 100, 30);
        add(chkict);
        
        JButton btnsearch = new JButton("SEARCH");
        btnsearch.setBounds(460, 20, 100, 30);
        add(btnsearch);
        
        JButton btnadd = new JButton("ADD");
        btnadd.setBounds(20, 450, 100, 30);
        add(btnadd);
        
        JButton btnupdate = new JButton("UPDATE");
        btnupdate.setBounds(130, 450, 100, 30);
        add(btnupdate);
        
        JButton btndelete = new JButton("DELETE");
        btndelete.setBounds(240, 450, 100, 30);
        add(btndelete);
        
        JButton btnclear = new JButton("CLEAR");
        btnclear.setBounds(350, 450, 100, 30);
        add(btnclear);
        
        JButton btnback = new JButton("BACK");
        btnback.setBounds(20, 490, 100, 30);
        add(btnback);
        
        tblstudent = new JTable();
        tblmodel = new DefaultTableModel(new String[]{"ID", "First Name", "Last Name", "Date of Birth", "Address", "Grade", "Fee"}, 0);
        tblstudent.setModel(tblmodel);
        JScrollPane tblscroll = new JScrollPane(tblstudent);
        tblscroll.setBounds(580, 20, 600, 150);
        add(tblscroll);
        
        tblstudenttele = new JTable();
        tblmodel2 = new DefaultTableModel(new String[]{"ID", "Telephone Number"}, 0);
        tblstudenttele.setModel(tblmodel2);
        JScrollPane tblscroll2 = new JScrollPane(tblstudenttele);
        tblscroll2.setBounds(580, 180, 600, 150);
        add(tblscroll2);
        
        //Event handling
        btnadd.addActionListener(e -> {
            String id = txtid.getText().trim();
            String fname = txtfname.getText().trim();
            String lname = txtlname.getText().trim();
            String dob = ((String) cboxday.getSelectedItem()) + "/" +
                 ((String) cboxmonth.getSelectedItem()) + "/" +
                 ((String) cboxyear.getSelectedItem());
            String address = txtaddress.getText().trim();
            String grade1 = (String) cboxgrade.getSelectedItem();
            String fee = txtfee.getText().trim();
            String tele1 = txttele1.getText().trim();
            String tele2 = txttele2.getText().trim();

            try {
                // Validate ID
                if (id.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please add an ID number!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
                }
                if (!id.matches("std\\d+")) { // Example: ID must start with "std" followed by digits
                    JOptionPane.showMessageDialog(null, "ID must be in the format 'std001'!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
                }
                
                // Validate other fields
                if (fname.isEmpty() || lname.isEmpty() || address.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
                }

                // Add user to the database
                stdcon.addStudent(id, fname, lname, dob, address, Integer.parseInt(grade1), Double.parseDouble(fee));
                stdcon.addStudentTele(id, tele1);
                stdcon.addStudentTele(id, tele2);

                // Refresh table
                refreshTable();

                JOptionPane.showMessageDialog(null, "User added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                // Clear fields
                txtid.setText(null);
                txtfname.setText(null);
                txtlname.setText(null);
                txtaddress.setText(null);
                txtfee.setText(null);
                cboxgrade.setSelectedIndex(-1);
                cboxday.setSelectedIndex(-1);
                cboxmonth.setSelectedIndex(-1);
                cboxyear.setSelectedIndex(-1);
                txttele1.setText(null);
                txttele2.setText(null);
                chkmaths.setSelected(false);
                chkscs.setSelected(false);
                chksin.setSelected(false);
                chkeng.setSelected(false);
                chkhis.setSelected(false);
                chktml.setSelected(false);
                chkict.setSelected(false);

            } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Grade and fee must be valid numbers!", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "An error occurred: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }       
        });
        
        btnupdate.addActionListener(e -> {
            String id = txtid.getText().trim();
            String fname = txtfname.getText().trim();
            String lname = txtlname.getText().trim();
            String dob = ((String) cboxday.getSelectedItem()) + 
                 ((String) cboxmonth.getSelectedItem()) + 
                 ((String) cboxyear.getSelectedItem());
            String address = txtaddress.getText().trim();
            String grade1 = (String) cboxgrade.getSelectedItem();
            String fee = txtfee.getText().trim();
            String tele1 = txttele1.getText().trim();
            String tele2 = txttele2.getText().trim();
            try {
                if (id.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please add an ID number!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
                }

                // Add user to the database
                stdcon.updateStudent(id, fname, lname, dob, address, Integer.parseInt(grade1), Double.parseDouble(fee));
                stdcon.updateStudentTele(id, tele1);
                stdcon.updateStudentTele(id, tele2);

                // Refresh table
                refreshTable();
                
                JOptionPane.showMessageDialog(this, "User updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                // Clear fields
                txtid.setText(null);
                txtfname.setText(null);
                txtlname.setText(null);
                txtaddress.setText(null);
                txtfee.setText(null);
                cboxgrade.setSelectedIndex(-1);
                cboxday.setSelectedIndex(-1);
                cboxmonth.setSelectedIndex(-1);
                cboxyear.setSelectedIndex(-1);
                txttele1.setText(null);
                txttele2.setText(null);
                chkmaths.setSelected(false);
                chkscs.setSelected(false);
                chksin.setSelected(false);
                chkeng.setSelected(false);
                chkhis.setSelected(false);
                chktml.setSelected(false);
                chkict.setSelected(false);

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID must be a valid number!", "Error", JOptionPane.ERROR_MESSAGE);
            }

        });
        
        btndelete.addActionListener(e -> {
            String id = txtid.getText();
            try {
                if (id.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please add an ID number!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
                }

                // Add user to the database
                stdcon.deleteStudent(id);

                // Refresh table
                refreshTable();
                
                JOptionPane.showMessageDialog(this, "User deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                // Clear fields
                txtid.setText(null);
                txtfname.setText(null);
                txtlname.setText(null);
                txtaddress.setText(null);
                txtfee.setText(null);
                cboxgrade.setSelectedIndex(-1);
                cboxday.setSelectedIndex(-1);
                cboxmonth.setSelectedIndex(-1);
                cboxyear.setSelectedIndex(-1);
                txttele1.setText(null);
                txttele2.setText(null);
                chkmaths.setSelected(false);
                chkscs.setSelected(false);
                chksin.setSelected(false);
                chkeng.setSelected(false);
                chkhis.setSelected(false);
                chktml.setSelected(false);
                chkict.setSelected(false);

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID must be a valid number!", "Error", JOptionPane.ERROR_MESSAGE);
            }
            refreshTable();
        });
        
        btnclear.addActionListener(e -> {
            // Clear fields
                txtid.setText(null);
                txtfname.setText(null);
                txtlname.setText(null);
                txtaddress.setText(null);
                txtfee.setText(null);
                cboxgrade.setSelectedIndex(-1);
                cboxday.setSelectedIndex(-1);
                cboxmonth.setSelectedIndex(-1);
                cboxyear.setSelectedIndex(-1);
                txttele1.setText(null);
                txttele2.setText(null);
                chkmaths.setSelected(false);
                chkscs.setSelected(false);
                chksin.setSelected(false);
                chkeng.setSelected(false);
                chkhis.setSelected(false);
                chktml.setSelected(false);
                chkict.setSelected(false);
            refreshTable();
        });
        
        btnsearch.addActionListener(e -> {
            try {
                    String id = txtid.getText();
                    StudentModel stdmodel = stdcon.searchUser(id);
                    if (stdmodel != null) {
                        txtfname.setText(stdmodel.getFname());
                        txtlname.setText(stdmodel.getLname());
                        txtaddress.setText(stdmodel.getAddress());
                        txtfee.setText(String.valueOf(stdmodel.getFee()));
                        cboxgrade.setSelectedItem(String.valueOf(stdmodel.getGrade()));
                        cboxday.setSelectedItem(stdmodel.getDob());
                        cboxmonth.setSelectedItem(stdmodel.getDob());
                        cboxyear.setSelectedItem(stdmodel.getDob());
                    }
                    else {
                        JOptionPane.showMessageDialog(this, "User not found!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
            } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Please enter a valid ID!", "Error", JOptionPane.ERROR_MESSAGE);
            }
            refreshTable();
        });
        
        tblstudent.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int selectedRow = tblstudent.getSelectedRow(); // Get the selected row index
                if (selectedRow != -1) {
                    // Load data from the selected row into the text fields
                    txtid.setText(tblmodel.getValueAt(selectedRow, 0).toString());
                    //txtname.setText(tblmodel.getValueAt(selectedRow, 1).toString());
                    //txtaddress.setText(tblmodel.getValueAt(selectedRow, 2).toString());
                }
            }
        });
        
        chkmaths.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chkmaths.isSelected()) {
                    fps=fps+500;
                    txtfee.setText(String.valueOf(fps));
                } else {
                    fps=fps-500;
                    txtfee.setText(String.valueOf(fps));
                }
            }
        });
        
        chkscs.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chkscs.isSelected()) {
                    fps=fps+500;
                    txtfee.setText(String.valueOf(fps));
                } else {
                    fps=fps-500;
                    txtfee.setText(String.valueOf(fps));
                }
            }
        });
        
        chksin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chksin.isSelected()) {
                    fps=fps+500;
                    txtfee.setText(String.valueOf(fps));
                } else {
                    fps=fps-500;
                    txtfee.setText(String.valueOf(fps));
                }
            }
        });
        
        chkeng.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chkeng.isSelected()) {
                    fps=fps+500;
                    txtfee.setText(String.valueOf(fps));
                } else {
                    fps=fps-500;
                    txtfee.setText(String.valueOf(fps));
                }
            }
        });
        
        chkhis.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chkhis.isSelected()) {
                    fps=fps+500;
                    txtfee.setText(String.valueOf(fps));
                } else {
                    fps=fps-500;
                    txtfee.setText(String.valueOf(fps));
                }
            }
        });
        
        chktml.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chktml.isSelected()) {
                    fps=fps+500;
                    txtfee.setText(String.valueOf(fps));
                } else {
                    fps=fps-500;
                    txtfee.setText(String.valueOf(fps));
                }
            }
        });
        
        chkict.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chkict.isSelected()) {
                    fps=fps+500;
                    txtfee.setText(String.valueOf(fps));
                } else {
                    fps=fps-500;
                    txtfee.setText(String.valueOf(fps));
                }
            }
        });
        
        btnback.addActionListener(e -> {
            this.dispose();
        });

        
        refreshTable();
        cboxgrade.setSelectedIndex(-1);
        cboxday.setSelectedIndex(-1);
        cboxmonth.setSelectedIndex(-1);
        cboxyear.setSelectedIndex(-1);
        chkmaths.setSelected(false);
        chkscs.setSelected(false);
        chksin.setSelected(false);
        chkeng.setSelected(false);
        chkhis.setSelected(false);
        chktml.setSelected(false);
        chkict.setSelected(false);
        
        
        
    }
    
    private void refreshTable() {
        tblmodel.setRowCount(0);
        List<String[]> users = stdcon.readStudents();
        for (String[] user : users) {
            tblmodel.addRow(user);
        }
        
        tblmodel2.setRowCount(0);
        List<String[]> users2 = stdcon.readStudentTele();
        for (String[] user : users2) {
            tblmodel2.addRow(user);
        }
    }
    
    
    
}
