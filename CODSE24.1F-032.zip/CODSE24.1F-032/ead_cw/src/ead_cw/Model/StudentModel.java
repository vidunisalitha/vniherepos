/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ead_cw.Model;

/**
 *
 * @author Vnihe
 */
public class StudentModel {
    private String id;
    private String fname;
    private String lname;
    private String dob;
    private String address;
    private int grade;
    private double fee;
    
    
    public StudentModel(String id, String fname, String lname, String dob, String address, int grade, double fee) {
        this.id =id;
        this.fname =fname;
        this.lname =lname;
        this.dob =dob;
        this.address =address;
        this.grade =grade;
        this.fee =fee;
    }
    
    public String getId(){ 
        return id;
    }
    
    public void setId(String id){
        this.id = id;
    }
    
    public String getFname(){ 
        return fname;
    }
    
    public void setFname(String fname){
        this.fname =fname;
    }
    
    public String getLname(){ 
        return lname;
    }
    
    public void setLname(String lname){
        this.lname =lname;
    }
    
    public String getDob(){ 
        return dob;
    }
    
    public void setDob(String dob){
        this.dob = dob;
    }
    
    public String getAddress(){ 
        return address;
    }
    
    public void setAddress(String address){
        this.address = address;
    }
    
    public int getGrade(){ 
        return grade;
    }
    
    public void setGrade(int grade){
        this.grade = grade;
    }
    
    public double getFee(){ 
        return fee;
    }
    
    public void setFee(double fee){
        this.fee = fee;
    }
    
    
    
    
}
