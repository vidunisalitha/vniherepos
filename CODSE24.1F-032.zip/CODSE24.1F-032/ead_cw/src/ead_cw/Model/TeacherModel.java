/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ead_cw.Model;

/**
 *
 * @author Vnihe
 */
public class TeacherModel {
    private String id;
    private String fname;
    private String lname;
    private String nic;
    private String address;
    private String subject;
    private double salary;
    
    
    public TeacherModel(String id, String fname, String lname, String nic, String address, String subject, double salary) {
        this.id =id;
        this.fname =fname;
        this.lname =lname;
        this.nic =nic;
        this.address =address;
        this.subject =subject;
        this.salary =salary;
    }
    
    public String getId(){ 
        return id;
    }
    
    public void setId(String id){
        this.id = id;
    }
    
    public String getFname(){ 
        return fname;
    }
    
    public void setFname(String fname){
        this.fname =fname;
    }
    
    public String getLname(){ 
        return lname;
    }
    
    public void setLname(String lname){
        this.lname =lname;
    }
    
    public String getNic(){ 
        return nic;
    }
    
    public void setNic(String nic){
        this.nic =nic;
    }
    
    public String getAddress(){ 
        return address;
    }
    
    public void setAddress(String address){
        this.address = address;
    }
    
    public String getSubject(){ 
        return subject;
    }
    
    public void setSubject(String subject){
        this.subject = subject;
    }
    
    public double getSalary(){ 
        return salary;
    }
    
    public void setSalary(double salary){
        this.salary = salary;
    }
    
    
    
    
}
